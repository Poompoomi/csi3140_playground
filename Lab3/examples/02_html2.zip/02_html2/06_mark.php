<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Welcome</title>
   </head>
   <body>
      <p>I <mark>understand</mark> nothing</p>
   </body>
</html>