<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Welcome</title>
    <style>
      .skinny {width: 200px;}
    </style>
   </head>
   <body>
      <figure>
        <img src="giffy.gif" alt="I understand nothing" class="skinny" />
        <figcaption>I understand nothing</figcaption>
      </figure>
   </body>
</html>