<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Welcome</title>
   </head>
   <body>
      <header>The Top</header>
      <section>Section 1</section>
      <section>Section 2</section>
      <footer>The Bottom</footer>

<!--       
      <div class="header">The Top</div>
      <div class="section">Section 1</div>
      <div class="section">Section 2</div>
      <div class="footer">The Bottom</div>
 -->
   </body>
</html>