<?php
require_once ("../examples.php");
show_examples();
